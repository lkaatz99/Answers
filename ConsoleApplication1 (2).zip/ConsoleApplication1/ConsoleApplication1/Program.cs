﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            // question 1
            int nMax = 4000000;
            myFibonacci fib = new myFibonacci();

            fib.Max = nMax;

            Console.WriteLine("Question 1:\n");
            Console.WriteLine(string.Format("Sum of all even number terms in Fibonacci sequence,\n" + 
                    "not to exceed {0}\n" +
                    "= {1}", nMax, fib.CalculateEvenNumberSum()));
            

            // question 2
            int nNatural = 100;
            Question2 q2 = new Question2();

            q2.Natural = nNatural;

            Console.WriteLine("\n");
            Console.WriteLine("Question 2:\n");
            Console.WriteLine(string.Format("Difference between the sum of the squares\n" +
                    "of the first {0} natural numbers and the square of the sum:\n" +
                    "= {1}", nNatural, q2.Difference()));


            // question 
            int nSize = 99;
            Question3 q3 = new Question3();

            Console.WriteLine("\n");
            Console.WriteLine("Question 3:\n");
            Console.WriteLine(string.Format("Difference between the sum of the squares\n" +
                    "of the first {0} natural numbers and the square of the sum:\n" +
                    "= {1}", nSize.ToString().Length, q3.GetlargestPalindromic(nSize)));


            // question 4
            int nIndex = 10001;
            Question4 q4 = new Question4();

            q4.Index = nIndex;

            Console.WriteLine("\n");
            Console.WriteLine("Question 4:\n");
            Console.WriteLine(string.Format("What is the {0}st prime number?\n" +
                    "= {1}", nIndex, q4.GetPrimeNumber()));

            Console.WriteLine("\n");
            Console.WriteLine("Press any key to close console.\n");
            Console.ReadKey();
        }
    }
}
