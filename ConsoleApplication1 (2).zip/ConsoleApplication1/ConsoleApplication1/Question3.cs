﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Question3
    {
        public int GetlargestPalindromic(int numSize)
        {
            int nProduct = 0;

            for (int i = numSize; i > 0; i--)
            {
                for (int j = numSize; j > 0; j--)
                {
                    nProduct = i * j;

                    if (IsPalindromic(nProduct))
                    {
                        return nProduct;
                    }
                }
            }

            return nProduct;
        }

        private bool IsPalindromic(int value)
        {
            int n = value;
            int rev = 0;

            while (value > 0)
            {
                int digit = value % 10;

                rev = rev * 10 + digit;
                value = value / 10;
            }

            return (n == rev);
        }
    }
}
