﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Question4
    {
        private int m_nIndex = 0;

        public int Index
        {
            set
            {
                m_nIndex = value;
            }
        }

        public int GetPrimeNumber()
        {
            int nNum = 0;
            int nIndex = 1;

            while (nIndex <= m_nIndex)
            {
                nNum++;
                if (this.IsPrime(nNum))
                {
                    nIndex++;
                }
            }

            return nNum;
        }

        private bool IsPrime( int num )
        {
            if (num == 1) return false;
            if (num == 2) return true;

            for (int i = 2; i < num; ++i)
            {
                if (num % i == 0) return false;
            }

            return true;
        }
            
    }
}
