﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class myFibonacci
    {
        private int m_nMax = 0;

        public int Max
        {
            set
            {
                m_nMax = value;
            }
        }

        public int CalculateEvenNumberSum()
        {
            int nTotal = 0;
            int i = 0;

            while( true )
            {
                int num = this.Fibonacci(i++);

                if (num <= this.m_nMax)
                {
                    if ((num % 2) == 0)
                    {
                        nTotal += num;
                    }
                }
                else
                {
                    break;
                }
            }
            return nTotal;
        }

        private int Fibonacci(int value)
        {
            if (value <= 1)
                return 1;
            return this.Fibonacci(value - 1) + this.Fibonacci(value - 2);
        }
    }
}
