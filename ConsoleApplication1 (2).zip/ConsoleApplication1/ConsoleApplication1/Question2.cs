﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Question2
    {
        private int m_nNatural = 0;

        public int Natural
        {
            set
            {
                m_nNatural = value;
            }
        }

        public int Difference()
        {
            int nDiff = 0;

            nDiff = this.SquareOfTheSum() - this.SumOfTheSquares();

            return nDiff;
        }

        private int SumOfTheSquares()
        {
            int nVal = 0;

            for (int i = 1; i <= this.m_nNatural; i++)
            {
                nVal += i * i;
            }

            return nVal;
        }

        private int SquareOfTheSum()
        {
            int nVal = 0;

            for (int i = 1; i <= this.m_nNatural; i++)
            {
                nVal += i;
            }

            return nVal * nVal;
        }

    }
}
